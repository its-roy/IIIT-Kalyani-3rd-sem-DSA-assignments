#include<iostream>
#include <list>
#define NIL -1
using namespace std;


class Graph
{
	int V;
	list<int> *adj;
	void APUtil(int v, bool visited[], int disc[], int low[],
				int parent[], bool ap[]);
    void DFSUtil(int v, bool visited[]);
public:
	Graph(int V);
	void addEdge(int v, int w);
	void AP();
	void DFS(int v);
};

Graph::Graph(int V)
{
	this->V = V;
	adj = new list<int>[V];
}

void Graph::addEdge(int v, int w)
{
	adj[v].push_back(w);
	adj[w].push_back(v);
}


void Graph::APUtil(int u, bool visited[], int disc[],
									int low[], int parent[], bool ap[])
{

	static int time = 0;


	int children = 0;


	visited[u] = true;


	disc[u] = low[u] = ++time;

	list<int>::iterator i;
	for (i = adj[u].begin(); i != adj[u].end(); ++i)
	{
		int v = *i;

		if (!visited[v])
		{
			children++;
			parent[v] = u;
			APUtil(v, visited, disc, low, parent, ap);


			low[u] = min(low[u], low[v]);

			if (parent[u] == NIL && children > 1)
			ap[u] = true;


			if (parent[u] != NIL && low[v] >= disc[u])
			ap[u] = true;
		}


		else if (v != parent[u])
			low[u] = min(low[u], disc[v]);
	}
}


void Graph::AP()
{

	bool *visited = new bool[V];
	int *disc = new int[V];
	int *low = new int[V];
	int *parent = new int[V];
	bool *ap = new bool[V];


	for (int i = 0; i < V; i++)
	{
		parent[i] = NIL;
		visited[i] = false;
		ap[i] = false;
	}

	for (int i = 0; i < V; i++)
		if (visited[i] == false)
			APUtil(i, visited, disc, low, parent, ap);


	for (int i = 0; i < V; i++)
		if (ap[i] == true)
			cout << i << " ";
}


void Graph::DFSUtil(int v, bool visited[])
{

	visited[v] = true;
	cout << v << " ";


	list<int>::iterator i;
	for (i = adj[v].begin(); i != adj[v].end(); ++i)
		if (!visited[*i])
			DFSUtil(*i, visited);
}


void Graph::DFS(int v)
{

	bool *visited = new bool[V];
	for (int i = 0; i < V; i++)
		visited[i] = false;

	DFSUtil(v, visited);
}


int main()
{


	Graph g1(8);
	g1.addEdge(0, 1);
	g1.addEdge(1, 0);
	g1.addEdge(0, 2);
	g1.addEdge(2, 0);
	g1.addEdge(0, 3);
	g1.addEdge(3, 0);
	g1.addEdge(1, 2);
	g1.addEdge(2, 1);
	g1.addEdge(1, 4);
	g1.addEdge(4, 1);
	g1.addEdge(1, 5);
	g1.addEdge(5, 1);
	g1.addEdge(2, 5);
	g1.addEdge(5, 2);
	g1.addEdge(4, 5);
	g1.addEdge(5, 4);
	g1.addEdge(3, 6);
	g1.addEdge(6, 3);
	g1.addEdge(3, 7);
	g1.addEdge(7, 3);
	g1.addEdge(6, 7);
	g1.addEdge(7, 6);
	cout << "\nDFS:\n";
	g1.DFS(0);
	cout << "\nArticulation points in the graph \n";
	g1.AP();

	return 0;
}
