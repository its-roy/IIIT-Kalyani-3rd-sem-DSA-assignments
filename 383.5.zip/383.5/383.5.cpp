#include<iostream>
#include<cstdlib>
#include<math.h>
using namespace std;
class Point{
	public:
		int x,y;
};
float dist(Point p1,Point p2){
	float dis=sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
	return dis;
}
float simpledist(Point P[], int n) 
{ 
	float min = dist(P[0],P[1]); 
	for (int i = 0; i<n;i++) 
		for (int j = i+1;j<n;j++) 
			if (dist(P[i],P[j])<min) 
				min=dist(P[i],P[j]); 
	return min; 
} 
float min(float x,float y) 
{ 
	return (x<y)?x:y; 
} 


float closeststrip(Point strip[],int size,float d){
	float min=d;
	for(int i=0;i<size;i++){
		for(int j=i+1;j<size;j++){
			if(dist(strip[i],strip[j])<min)
			{
				min=dist(strip[i],strip[j]);
			}
		}
	}
	return min;
}
float closestutil(Point P[], int n) 
{ 	if (n <= 2) 
		return simpledist(P, n); 

	int mid = n/2; 
	Point midPoint = P[mid];  
	float dl = closestutil(P, mid); 
	float dr = closestutil(P + mid, n - mid);  
	float d = min(dl, dr); 
	Point strip[n]; 
	int j = 0; 
	for (int i = 0; i < n; i++) 
		if ((P[i].x-midPoint.x)<d) 
		{
				strip[j] = P[i];
				j++;
	    }
	return min(d,closeststrip(strip, j, d) ); 
} 
float closest(Point P[],int n){
	return closestutil(P,n);
}
int main(){
	Point P[100];
	int n;
	cout<<"\n Enter number of points: ";
	cin>>n;
	for(int i=0;i<n;i++){
		cout<<"\n Enter point "<<i+1<<": ";
		cin>>P[i].x;
		cin>>P[i].y;
	}
	cout<<"\n The smallest distance is: "<<closest(P,n);
	
}
