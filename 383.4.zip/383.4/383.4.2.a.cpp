#include<iostream>
#include<cstdlib>
#include <ctime>
using namespace std;
int swap(int *a,int *b){
	int temp=*a;
	*a=*b;
	*b=temp;
}
int partition(int a[],int p,int r){
	int pivot=a[r];
	int pindex=p;
	for(int i=p;i<=r-1;i++){
		if(a[i]<=pivot){
			swap(&a[i],&a[pindex]);
			pindex=pindex+1;
		}
	}
	swap(&a[pindex],&a[r]);
	return pindex;
}
int quicksort(int a[],int p,int r){
	if(p<r){
		int pindex=partition(a,p,r);
		quicksort(a,p,pindex-1);
		quicksort(a,pindex+1,r);
	}
}
int main(){
	int p=0, n;
	int a[50000];
	cout<<"\n Enter number of elements: ";
	cin>>n;
	for(int i=0;i<n;i++){
		a[i]=(rand()%1000)+1;
	}
	std::clock_t c_start = std::clock();
	quicksort(a,p,n-1);
	std::clock_t c_end = std::clock();
	for(int i=0;i<n;i++){
		cout<<a[i]<<" ";
	}
	long double time_elapsed_ms=1000.0*(c_end-c_start)/CLOCKS_PER_SEC;
    std::cout<<"\n\nCPU time used: "<<time_elapsed_ms<<" ms\n";
	return 0;
}
