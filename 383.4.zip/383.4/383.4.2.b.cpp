#include<iostream>
#include<cstdlib>
using namespace std;
int median[10000];
int medl=0;
int medr=-1;
int swap(int *a,int *b){
	int temp=*a;
	*a=*b;
	*b=temp;
}
int partition(int a[],int p,int r){
	int pivot=a[r];
	int pindex=p;
	for(int i=p;i<=r-1;i++){
		if(a[i]<=pivot){
			swap(&a[i],&a[pindex]);
			pindex=pindex+1;
		}
	}
	swap(&a[pindex],&a[r]);
	return pindex;
}
int quicksort(int a[],int p,int r){
	if(p<r){
		int pindex=partition(a,p,r);
		quicksort(a,p,pindex-1);
		quicksort(a,pindex+1,r);
	}
}
//This function will store medians of each group in array median
int median1(int a[],int l,int r){
     int med=(r+l)/2;
     medr++;
     median[medr]=a[med];
     
}
//This function will sort the array
int sort(int a[],int l,int r){
	
	for(int i=l;i<r;i++){
		for(int j=l;j<r;j++){
			if(a[j]>a[j+1]){
				swap(&a[j],&a[j+1]);
			}
		}
	}
}

int main(){
	int l=0, n,r=4;
	int a[50000];
	cout<<"\n Enter number of elements: ";
	cin>>n;
	// Storing n random numbers in a
	for(int i=0;i<n;i++){
		a[i]=(rand()%1000)+1;
	}
	//dividing the array in groups of 5 element and by sorting we will find median of each group 
	for(int i=5;i<=n;i=i+5){
	
		sort(a,l,r);
		median1(a,l,r);
		l=r+1;
		r=r+5;
    }
    sort(median,medl,medr);  //Sorting the array median 
    for(int i=0;i<n;i++){
    	if(a[i]==median[(medl+medr)/2])   // then we will swap the last element by the median of medians
    	    swap(&a[i],&a[n-1]);
	}
	quicksort(a,0,n-1);
   	for(int i=0;i<n;i++){
		cout<<a[i]<<" ";
		
	}
}
