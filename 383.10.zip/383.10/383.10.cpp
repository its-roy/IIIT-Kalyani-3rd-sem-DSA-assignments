#include<iostream>
#include<string.h>
using namespace std;
void computeLPSarray(string p,int lps[],int n){
	int i=0;
	int j=1;
	lps[i]=0;
	while(j<p.size()){
		if(i==0&&(p[i]!=p[j])){
			lps[j]=0;
			j++;		
		}
		else if(i>0&&(p[i]!=p[j])){
			i=lps[i-1];		
		}
		else if(p[i]==p[j]){
			lps[j]=i+1;
			i++;
			j++;		
		}
	}

	
}
void kmpalgorithm(string s,string p){
	int n=s.size();
	int lps[p.size()];
	computeLPSarray(p,lps,n);
	int j=0;
	int i=0;
	while (i<n) { 
		if(p[j]==s[i]){ 
		    j++; 
		    i++; 
		} 
	  
		else if (j==p.size()) { 
		    cout<<"\n Pattern found at: "<<i-j; 
		    j=lps[j-1]; 
		} 
		else if(p[j]!=s[i]) { 
		    if(j==0){
			i=i+1;
		    } else{
			j=lps[j-1];
		    }
		} 
       } 
	
}
int main(){
	string s="banananobano";
	string p="nano";
	kmpalgorithm(s,p);
	return 0;
}
