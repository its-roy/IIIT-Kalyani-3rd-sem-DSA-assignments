#include<stdio.h>
#include<stdlib.h>
struct node 
{
	int info;
	struct node *left, *right;
};
struct node *newnode(int value)
{
	struct node *newp=(struct node*)malloc(sizeof(struct node));
	newp->info=value;
	newp->left=NULL;
	newp->right=NULL;
	return newp;
}
struct node *constructtree(int pre[],int post[],int *index, int l, int h,int size)
{   
int i;
	if(*index>=size || l>h)
	{
	return NULL;
}
	struct node *root=newnode(pre[*index]);
	++*index;
	if(l==h)
	{
	return root;
}
	for(i=l;i<=h;i++)
	{
		if(pre[*index]==post[i])
		break;
	}
	if(i<=h)
	{
		root->left=constructtree(pre, post, index, l, i, size);
       root->right=constructtree(pre, post, index, i+1, h, size);
	}
	return root;
}
struct node *createbst(int pre[], int post[], int size)
{
	int index =0;
	return constructtree(pre,post,&index,0,size-1,size);
}
void inorder(struct node *ptr)
{
	if(ptr==NULL)
	return;
	inorder(ptr->left);
	printf("%d\n",ptr->info);
	inorder(ptr->right);
}
int main()
{
	int i,pre[100], post[100],size;
	printf("enter the size of tree");
	scanf("%d",&size);
	printf("enter the elements of  preorder");
	for(i=0;i<size;i++)
	{
		scanf("%d",&pre[i]);
	}
	printf("enter the elements of  postorder");
	for(i=0;i<size;i++)
	{
		scanf("%d",&post[i]);
	}
	struct node *root=createbst(pre, post, size);
	printf("inorder traversal is");
	inorder(root);
	return 0;
}
