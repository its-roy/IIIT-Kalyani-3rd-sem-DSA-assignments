#include<bits/stdc++.h>
using namespace std;


struct node{
	int info;
    struct node *left;
    struct node *right;
};

struct node* insert(struct node *root, int item);
void search(int item);
void preorder(struct node *t);
struct node *root = NULL;
struct node *LOC, *PAR;

int main()
{
    int i, item;
    do
    {
    	cout<<"\n1.  Insert elements into tree\n";
    	cout<<"2.  Search the element\n";
    	cout<<"3.  Exit\n";
        cout<<"\nEnter your choice : ";
        cin>>i;
        switch (i)
        {
        case 1:
        	cout<<"Enter -1 to terminate\n";
			cout<<"Enter data items :\n";
			cin>>item;
			while(item!=-1)
			{
			    root=insert(root,item);
				cout<<"Enter data items :\n";
				cin>>item;
			}
			cout<<"Binary tree is created\n\n";
			preorder(root);
        break;
        case 2:    
            cout<<"Enter element you want to search\n";
			cin>>item;
			search(item);
                if(LOC != NULL)
                    cout<<item <<" is present in Binary Search Tree \n";
                else
                    cout<<"Element not Present\n";
        break;
        }
    }while(i<3);

    return 0;

}



struct node* insert(struct node *root, int item)
{
	struct node *p;
    p=(struct node *)malloc(sizeof(struct node));
    p->info=item;
    p->right=NULL;
    p->left=NULL;
    if(root==NULL)
    {
        root=p;
    }
    else
    {
        struct node *q,*r;
        q=root;
        while(q!=NULL)
        {
            r=q;
            if(p->info>=q->info)
            {
              q=q->right;
            }
            else if(p->info<q->info)
            {
                q=q->left;
            }
        }
        if(p->info>=r->info)
        {
            r->right=p;
        }
        else if(p->info<r->info)
        {
            r->left=p;
        }
    }
    return root;
}



void search(int item)
{
    struct node *save,*ptr;
    if (root == NULL)
    {
        LOC = NULL;
        PAR=NULL;
    }
    if (item == root -> info)
    {
    LOC = root;
    PAR = NULL;
    return;
    }
    if (item < root->info)
    {
    	ptr = root->left;
        save = root;
    }
    else
    {
    	ptr = root -> right;
        save = root;
    }
    while( ptr != NULL)
    {
        if (ptr -> info == item)
        {
            LOC = ptr;
            PAR = save;
            return;
        }
        if(item < ptr->info)
        {
            save = ptr;
            ptr = ptr->left;
        }
        else
        {
            save = ptr;
            ptr = ptr->right;
        }
    }
    LOC = NULL;
    PAR = save;
    return;

}



void preorder(struct node *t)
{
    if (root == NULL)
    {
        cout<<"BST is Empty";
        return;
    }
    cout<<t->info<<"    ";
    if (t->left != NULL)    
        preorder(t->left);
    if (t->right != NULL)    
        preorder(t->right);
}


