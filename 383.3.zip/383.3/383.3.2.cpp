//to make heap sort for strings in dictionary order
#include<iostream>
#include<cstdlib>
#include <fstream>
using namespace std;
void minHeapify(string [], int, int);
void heapsort(string [], int);
void build_minheap(string [], int);
int insert_minheap(string [], int, string);
int main(){
    int n;
    string a[20];
    FILE *fptr1;
    fptr1=fopen("roy1.txt", "r");
    char word[10];
    int j=1, count=0;
    while(fscanf(fptr1, "%s ", word)>0){
        a[j++]=word;
        count++;
    }
    fclose(fptr1);
    cout<<"Enter the amount of strings to fetch and sort from file:"<<endl;
    cin>>n;
    build_minheap(a,n);
    heapsort(a, n);
    cout<<"Enter the no. of item to be inserted :"<<endl;
    int ni;;
    cin>>ni;
    string item;
    while(ni--){
        cout<<"Enter the string to be inserted:"<<endl;
        cin>>item;
        n=insert_minheap(a, n, item);
    }
  ofstream file;
   file.open("roy2.txt");
   for(int k=1;k<=n;k++){
     file<<a[k]<<" ";
   }
    file.close();
    cout<<"When file goes out of scope, the ofstream destructor will close the file"<<endl;
    return 0;
}
void min_heapify(string a[], int i, int n){
    int j;
    string temp;
    temp=a[i];
    j=2*i;
    while(j<=n){
        if (j<n && a[j+1]<a[j])
            j = j+1;
        if (temp<a[j])
            break;
        else if(temp>=a[j]){
            a[j/2] = a[j];
            j = 2*j;
        }
    }
    a[j/2] = temp;
    return;
}
void heapsort(string a[], int n){
    for (int i=n; i>=2;i--){
        swap(a[1], a[i]);
        min_heapify(a, 1, i - 1);
    }
    cout<<"\nLexogrpahic descending order of strings is:\n";
    for (int i=1;i<=n;i++){
        cout<<a[i]<<endl;
    }
}
void build_minheap(string a[], int n){
    for(int i=n/2;i>=1;i--){
        min_heapify(a, i, n);
    }
}
int insert_minheap(string a[], int n, string item){
    n+=1;
    a[n]=item;
    build_minheap(a, n);
    heapsort(a, n);
    return n;
}
