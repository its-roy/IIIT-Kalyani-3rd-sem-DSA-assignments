//to make heap sort
#include<iostream>
using namespace std;
void minHeapify(int *, int, int);
void heapsort(int *, int);
void build_minheap(int *, int);
int insert_minheap(int *, int, int);
int main(){
    int n;
    cout<<"Enter the amount of numbers to be sorted: "<<endl;
    cin>>n;
    cout<<"Enter the elements in the array :"<<endl;
    int a[20];
    for(int i=1;i<=n;i++){
        cout<<"Enter the "<<i<<"th element: "<<endl;
        cin>>a[i];
    }
    cout<<"The sorted array is :"<<endl;
    build_minheap(a,n);
    heapsort(a, n);
    cout<<"\nSorted Array\n";
    for (int i=1;i<=n;i++){
        cout<<a[i]<<endl;
    }
    cout<<"Enter the no. of item to be inserted :"<<endl;
    int ni;;
    cin>>ni;
    int item;
    while(ni--){
        cout<<"Enter the item to be inserted:"<<endl;
        cin>>item;
        n=insert_minheap(a, n, item);
    }
    return 0;
}
void min_heapify(int *a, int i, int n){
    int j, temp;
    temp=a[i];
    j=2*i;
    while(j<=n){
        if (j<n && a[j+1]<a[j])
            j = j+1;
        if (temp<a[j])
            break;
        else if(temp>=a[j]){
            a[j/2] = a[j];
            j = 2*j;
        }
    }
    a[j/2] = temp;
    return;
}
void heapsort(int *a, int n){
    for (int i=n; i>=2;i--){
        swap(a[1], a[i]);
        min_heapify(a, 1, i - 1);
    }
}
void build_minheap(int *a, int n){
    for(int i=n/2;i>=1;i--){
        min_heapify(a, i, n);
    }
}
int insert_minheap(int *a, int n, int item){
    n+=1;
    a[n]=item;
    build_minheap(a, n);
    heapsort(a, n);
    cout<<"\nSorted Array\n";
    for (int i=1;i<=n;i++){
        cout<<a[i]<<endl;
    }
    return n;
}