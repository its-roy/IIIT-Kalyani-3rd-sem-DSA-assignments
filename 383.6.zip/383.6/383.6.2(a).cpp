#include<bits/stdc++.h>
using namespace std;
class dset
{
	int *parent,n;
	public:
	dset(int n1)
	{
		parent = new int[n];
		n = n1;
		makeset();
	}
	void makeset();
	int find(int x);
};

void dset :: makeset()
{
	for(int i=0;i<n;i++)
	{
		parent[i] = i;
	}
} 
int dset :: find(int x)
{
	if(parent[x] != x)
	{
        parent[x] = find(parent[x]);
	}
	return parent[x];
}
int main()
{
	dset obj(5);
	cout<<"Printing the parent of different element in disjoint set using find function :\n";
	for(int i=0;i<5;i++)
	{
		cout<<"Parent of "<<i<<" is "<<obj.find(i)<<endl;
	}
	return 0;
}
